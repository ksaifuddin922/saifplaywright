import yaml

def load_config(env="default"):
    with open("config/config.yaml", 'r') as file:
        configs = yaml.safe_load(file)
    return configs.get(env, configs["default"])
