import time
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

class Wrapper:
    def __init__(self, page):
        self.page = page

    def click_with_retry(self, selector, retries=3, delay=1):
        for attempt in range(retries):
            try:
                self.page.click(selector)
                return
            except PlaywrightTimeoutError:
                if attempt < retries - 1:
                    time.sleep(delay)
                else:
                    raise Exception(f"Failed to click element: {selector} after {retries} attempts")

    def wait_and_fill(self, selector, text, timeout=5000):
        self.page.wait_for_selector(selector, timeout=timeout)
        self.page.fill(selector, text)

    def wait_and_get_text(self, selector, timeout=5000):
        self.page.wait_for_selector(selector, timeout=timeout)
        return self.page.inner_text(selector)

    def wait_until_visible(self, selector, timeout=5000):
        self.page.wait_for_selector(selector, timeout=timeout)
        return self.page.is_visible(selector)
