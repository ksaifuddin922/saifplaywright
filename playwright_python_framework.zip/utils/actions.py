class Actions:
    def __init__(self, page):
        self.page = page

    def click(self, selector):
        self.page.click(selector)

    def fill(self, selector, value):
        self.page.fill(selector, value)

    def upload_file(self, selector, file_path):
        self.page.set_input_files(selector, file_path)

    def download_file(self, download_trigger_selector):
        with self.page.expect_download() as download_info:
            self.page.click(download_trigger_selector)
        download = download_info.value
        return download.path()

    def get_text(self, selector):
        return self.page.inner_text(selector)

    def take_screenshot(self, path):
        self.page.screenshot(path=path)
