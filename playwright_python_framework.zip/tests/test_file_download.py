import pytest
from pages.download_page import DownloadPage
from utils.logger import get_logger

logger = get_logger()

@pytest.mark.filedownload
def test_file_download(page):
    page.goto("https://example.com/download")
    download = DownloadPage(page)
    file_path = download.download_file()
    assert file_path is not None
    logger.info(f"Downloaded file at: {file_path}")
