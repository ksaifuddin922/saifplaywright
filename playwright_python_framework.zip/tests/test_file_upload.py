import pytest
from pages.upload_page import UploadPage
from utils.logger import get_logger

logger = get_logger()

@pytest.mark.fileupload
def test_file_upload(page):
    page.goto("https://example.com/upload")
    upload = UploadPage(page)
    upload.upload("data/sample.txt")
    assert page.is_visible("text=Upload Successful")
    logger.info("File upload test passed")
