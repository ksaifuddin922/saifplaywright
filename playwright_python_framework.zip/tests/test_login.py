import pytest
from pages.login_page import LoginPage
from config.env_reader import load_config
from utils.logger import get_logger

logger = get_logger()

@pytest.mark.smoke
def test_login(page):
    config = load_config()
    page.goto(config["base_url"] + "/login")
    login_page = LoginPage(page)
    login_page.login("user", "password")
    assert "Dashboard" in page.title()
    logger.info("Login test passed")
