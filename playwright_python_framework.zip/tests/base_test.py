from config.env_reader import load_config

class BaseTest:
    def __init__(self, env='default'):
        self.config = load_config(env)
