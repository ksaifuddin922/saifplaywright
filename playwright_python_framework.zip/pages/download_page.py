from pages.base_page import BasePage

class DownloadPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.download_link = "a#download"

    def download_file(self):
        return self.actions.download_file(self.download_link)
