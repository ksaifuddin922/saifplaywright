from utils.actions import Actions

class BasePage:
    def __init__(self, page):
        self.page = page
        self.actions = Actions(page)
