from pages.base_page import BasePage

class LoginPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.username_input = "input#username"
        self.password_input = "input#password"
        self.login_button = "button#login"

    def login(self, username, password):
        self.actions.fill(self.username_input, username)
        self.actions.fill(self.password_input, password)
        self.actions.click(self.login_button)
