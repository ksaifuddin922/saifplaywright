from pages.base_page import BasePage

class UploadPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.upload_input = "input#upload"
        self.submit_button = "button#submit"

    def upload(self, file_path):
        self.actions.upload_file(self.upload_input, file_path)
        self.actions.click(self.submit_button)
